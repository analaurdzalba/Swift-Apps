//
//  History.swift
//  App06-Covid19
//
//  Created by Ana Laura Rodriguez on 09/04/21.
//

import SwiftUI
import SwiftUICharts

struct GraphsView: View {
    @StateObject var cases: DataModel
    var country: Cases
    @State var casesArr = [(String,Double)]()
    @State var deathsArr = [(String,Double)]()
    @State var vaccinesArr = [(String,Double)]()
    var body: some View{
        VStack{
            BarChartView(data: ChartData(values: casesArr),title: "Cases",style:Styles.barChartStyleNeonBlueLight, form: ChartForm.extraLarge, valueSpecifier: "%.0f")
            BarChartView(data: ChartData(values: deathsArr),title: "Deaths",style:Styles.barChartMidnightGreenLight, form: ChartForm.extraLarge, valueSpecifier: "%.0f")
            BarChartView(data: ChartData(values: vaccinesArr),title: "Vaccines",style:Styles.barChartStyleOrangeLight, form: ChartForm.extraLarge, valueSpecifier: "%.0f")
        }
        .onAppear{
            cases.getHistory(country: country.iso) { (returnedCases, returnedDeaths) in
                self.casesArr.append(contentsOf:returnedCases)
                self.deathsArr.append(contentsOf:returnedDeaths)
            }
            cases.getVaccines(country: country.iso) { (returnedVaccines) in
                self.vaccinesArr.append(contentsOf:returnedVaccines)
            }
        }
}
}
struct GraphsView_Previews: PreviewProvider{
    static var previews: some View{
        GraphsView(cases: DataModel(), country: Cases.dummy)
    }
}
