//
//  CountryView.swift
//  App06-Covid19
//
//  Created by Ana Laura Rodriguez on 09/04/21.
//

import SwiftUI
import Kingfisher

struct CountryView: View {
    @StateObject var cases: DataModel
    var country: Cases
    
    var body: some View {
        VStack {
            KFImage(URL(string: country.flag)!)
                .resizable()
                .frame(width: 240,height: 138)
                
                .overlay(
                    RoundedRectangle(cornerRadius:6)
                        .stroke(Color.black,lineWidth:1)
                
                )
                .padding(.top,30)
            VStack{
                DataView(title: "Cases:",value:country.cases)
                DataView(title: "Deaths:",value:country.deaths)
                DataView(title: "Recovered:",value:country.recovered)
                DataView(title: "Active:",value:country.active)
                DataView(title: "Critical:",value:country.critical)
                
            }
            .padding(.horizontal,80)
            NavigationLink(destination:GraphsView(cases: cases,country: country), label: {
                VStack{
                    Text("Gráficas")
                        .font(.Oswald(size:24))
                    Image(systemName: "chart.bar.fill")
                        .font(.largeTitle)
                }
            })
           
            Spacer()
            MapView(country:country)
                .padding(.bottom,40)
        }
        .navigationBarTitle(country.country)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct CountryView_Previews: PreviewProvider {
    static var previews: some View {
        CountryView (cases: DataModel(),country: Cases.dummy)
    }
}
