//
//  SwiftUIView.swift
//  App06-Covid19
//
//  Created by Ana Laura Rodriguez on 09/04/21.
//

import SwiftUI

struct DataView: View {
    var title: String
    var value: Double
    
    
    var body: some View {
        HStack {
            Text(title)
                .font(.Oswald(size:19))
            Spacer()
            Text(String(format: "%0.0f",value))
                .font(.Oswald(size:20))
                
            
        }
    }
}

struct DataView_Previews: PreviewProvider {
    static var previews: some View {
        DataView(title: "Cases: ",value: 1000000)
    }
}
