//
//  ContentView.swift
//  App06-Covid19
//
//  Created by Ana Laura Rodriguez on 09/04/21.
//

import SwiftUI

struct ListView: View {
    @StateObject var cases = DataModel()
    
    var body: some View {
        NavigationView{
            VStack {
                List(cases.casesList) {country in
                    NavigationLink(
                        destination: CountryView(cases:cases, country: country),
                        label: {
                            CountryCellView(country:country)
                        }
                    )
                }
                .listStyle(PlainListStyle())
            }
            .padding(.bottom,20)
            .navigationBarTitle("COVID-19")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

struct ListView_Preview: PreviewProvider {
    static var previews: some View {
        ListView()
    }
}
