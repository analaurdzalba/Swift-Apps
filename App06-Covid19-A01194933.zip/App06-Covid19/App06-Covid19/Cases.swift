//
//  Cases.swift
//  App06-Covid19
//
//  Created by Ana Laura Rodriguez on 09/04/21.
//

import SwiftUI

struct Cases: Identifiable {
    
    var id = UUID()
    var country: String
    var iso: String
    var lat: Float
    var long: Float
    var flag: String
    var cases: Double
    var deaths: Double
    var recovered: Double
    var active: Double
    var critical: Double
    var population: Double
    var continent: String
    
    
}

extension Cases {
    
    static let dummy = Cases(country: "Argentina" , iso: "ARG", lat: -34, long: -64, flag: "https://disease.sh/assets/img/flags/ar.png", cases: 2278115, deaths: 0, recovered: 2056472, active: 166551, critical: 3585, population: 45498383, continent: "South America")
}
