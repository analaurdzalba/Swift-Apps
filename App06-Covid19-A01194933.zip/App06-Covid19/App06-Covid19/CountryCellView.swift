//
//  CountryCellView.swift
//  App06-Covid19
//
//  Created by Ana Laura Rodriguez on 09/04/21.
//

import SwiftUI
import Kingfisher

struct CountryCellView: View {
    
    var country: Cases
    
    var body: some View {
        VStack {
       
            HStack {
                VStack {
                    Text(country.country)
                        .font(.Oswald(size:24))
                    KFImage(URL(string: country.flag)!)
                        .resizable()
                        .frame(width: 120,height: 69)
                        .padding(.top,-2)
                        .cornerRadius(6)
                        .overlay(
                            RoundedRectangle(cornerRadius:6)
                                .stroke(Color.black,lineWidth:1)
                        
                        )
                    
                }
                VStack {
                    Spacer()
                      
                    DataView(title: "Cases:", value: country.cases)
                    DataView(title: "Deaths:",value: country.deaths)
                    DataView(title: "Recovered:",value: country.recovered)
                    Spacer()
                }
  
     
            }
            .padding(.horizontal,20)
            Spacer()
        }
    
        
    }
}

struct CountryCellView_Previews: PreviewProvider {
    static var previews: some View {
        CountryCellView(country: Cases.dummy)
    }
}
