//
//  App06_Covid19App.swift
//  App06-Covid19
//
//  Created by Ana Laura Rodriguez on 09/04/21.
//

import SwiftUI

@main
struct App06_Covid19App: App {
    var body: some Scene {
        WindowGroup {
            ListView()
        }
    }
}
