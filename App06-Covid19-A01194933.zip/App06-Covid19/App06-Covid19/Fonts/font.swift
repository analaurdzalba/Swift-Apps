//
//  File.swift
//  App06-Covid19
//
//  Created by Ana Laura Rodriguez on 09/04/21.
//

import Foundation
import SwiftUI

extension Font {
    public static func Oswald(size: CGFloat) -> Font {
        return Font.custom("Oswald-Regular", size: size)
    }
   
}

